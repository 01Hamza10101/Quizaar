function Sc(){
  window.location.href = "/SUB10/C10CWQ/CWQ.html";
}

function Ssc(){
  alert("Sorry, Currently not available!")
}

function Mat(){
  alert("Sorry, Currently not available!")
}
function Eng(){
  alert("Sorry, Currently not available!")
}

function Hin(){
alert("Sorry, Currently not available!")
}

function Back(){
  history.back()
}