function navigateToHomePage() {
    window.location.href = "/index.html";
}

function PYQ2023() {
    window.location.href = "/Class10th/PYQ23/quiz app.html";
}
