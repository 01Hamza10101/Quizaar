function navigateToHomePage() {
    window.location.href = "/Quizaar/Quiz.html";
}
